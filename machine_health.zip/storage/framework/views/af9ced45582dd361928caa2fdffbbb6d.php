<?php if(session('success')): ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    Swal.fire({
        title: 'Berhasil',
        text: <?php echo json_encode(session('success'), 15, 512) ?>,
        icon: 'success',
        confirmButtonText: 'OK',
        confirmButtonColor: '#3085d6'
    });
});
</script>
<?php endif; ?>


<?php if(session('info')): ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    Swal.fire({
        title: 'Gagal',
        text: <?php echo json_encode(session('info'), 15, 512) ?>,
        icon: 'info',
        confirmButtonText: 'OK',
        confirmButtonColor: '#d33'
    });
});
</script>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\machine_health\resources\views/layout/alert.blade.php ENDPATH**/ ?>