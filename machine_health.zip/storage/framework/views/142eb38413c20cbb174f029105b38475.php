<!DOCTYPE html>
<html lang="en" dir="ltr" data-startbar="light" data-bs-theme="light">

<head>
    <meta charset="utf-8" />
    <title><?php echo e(config('app.name')); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('dashboard')); ?>/assets/images/logos/logo.png">



    <link rel="stylesheet" href="<?php echo e(asset('dashboard')); ?>/assets/libs/jsvectormap/css/jsvectormap.min.css">
    <link href="<?php echo e(asset('dashboard')); ?>/assets/libs/simple-datatables/style.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('dashboard')); ?>/assets/libs/sweetalert2/sweetalert2.min.css" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('dashboard')); ?>/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('dashboard')); ?>/assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('dashboard')); ?>/assets/css/app.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('dashboard')); ?>/assets/package/dist/css/tom-select.bootstrap5.min.css" rel="stylesheet" type="text/css" />

</head>
<?php /**PATH C:\xampp\htdocs\machine_health\resources\views/layout/head.blade.php ENDPATH**/ ?>