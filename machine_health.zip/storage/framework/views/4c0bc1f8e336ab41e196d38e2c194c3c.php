<?php echo $__env->make('layout.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('layout.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<style>
    .ref-warning-page .badge-yes,
    .ref-warning-page .badge-no {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 86px;
        padding: 6px 10px;
        border-radius: 999px;
        font-size: 12px;
        font-weight: 700;
    }

    .ref-warning-page .badge-yes {
        color: #166534;
        background: #dcfce7;
    }

    .ref-warning-page .badge-no {
        color: #eb5a06;
        background: #f0eae2;
    }
</style>

<div class="page-content ref-warning-page">
    <div class="container-xxl">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <div class="row align-items-center">
                            <div class="col">
                                <h4 class="card-title">Komatsu SN Code Reference</h4>
                            </div>
                        </div>
                    </div>

                    <div class="card-body pt-0">
                        <div class="table-responsive">
                            <table class="table datatable" id="datatable_1">
                                <thead class="table-light">
                                    <tr>
                                        <th>SN Code</th>
                                        <th>IP Address</th>
                                        <th>Equipment ID</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->SN_CODE); ?></td>
                                            <td><?php echo e($item->IP_ADDRESS); ?></td>
                                            <td><?php echo e($item->VHC_ID); ?></td>
                                            <td>
                                                <?php if($item->STATUS == 1): ?>
                                                    <span class="badge-yes">Checked</span>
                                                <?php else: ?>
                                                    <span class="badge-no">Need to be Checked</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <button type="button"
                                                    class="btn btn-outline-primary btn-sm edit-row-btn"
                                                    data-sn-code="<?php echo e($item->SN_CODE); ?>"
                                                    data-ip-address="<?php echo e($item->IP_ADDRESS); ?>"
                                                    data-vhc-id="<?php echo e($item->VHC_ID); ?>"
                                                    data-status="<?php echo e($item->STATUS); ?>">
                                                    Edit
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="warningModal" tabindex="-1" aria-labelledby="warningModalTitle" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <div>
                    <h5 class="modal-title" id="warningModalTitle">Edit Komatsu SN Code</h5>
                    <div class="text-muted small">Update SN Code reference data.</div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <form id="warningForm" method="POST" action="<?php echo e(route('komatsu.sn-ref.update')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="OLD_SN_CODE" id="formOldSnCode">

                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">SN Code</label>
                            <input type="text" class="form-control" name="SN_CODE" id="formSnCode" required>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label">IP Address</label>
                            <input type="text" class="form-control" name="IP_ADDRESS" id="formIpAddress">
                        </div>

                        <div class="col-md-6">
                            <label class="form-label">Equipment ID</label>
                            <input type="text" class="form-control" name="VHC_ID" id="formVhcId">
                        </div>

                        <div class="col-md-6">
                            <label class="form-label">Status</label>
                            <select class="form-select" name="STATUS" id="formStatus">
                                <option value="0">Need to be Checked</option>
                                <option value="1">Checked</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const modalElement = document.getElementById('warningModal');
    if (!modalElement) return;

    const editModal = bootstrap.Modal.getOrCreateInstance(modalElement);
    const formOldSnCode = document.getElementById('formOldSnCode');
    const formSnCode = document.getElementById('formSnCode');
    const formIpAddress = document.getElementById('formIpAddress');
    const formVhcId = document.getElementById('formVhcId');
    const formStatus = document.getElementById('formStatus');

    document.addEventListener('click', function (event) {
        const button = event.target.closest('.edit-row-btn');
        if (!button) return;

        formOldSnCode.value = button.dataset.snCode || '';
        formSnCode.value = button.dataset.snCode || '';
        formIpAddress.value = button.dataset.ipAddress || '';
        formVhcId.value = button.dataset.vhcId || '';
        formStatus.value = button.dataset.status || '0';

        editModal.show();
    });
});
</script>

<?php if(session('success')): ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    Swal.fire({
        title: 'Berhasil',
        text: <?php echo json_encode(session('success'), 15, 512) ?>,
        icon: 'success',
        confirmButtonText: 'OK'
    });
});
</script>
<?php endif; ?>

<?php if(session('error')): ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    Swal.fire({
        title: 'Gagal',
        text: <?php echo json_encode(session('error'), 15, 512) ?>,
        icon: 'error',
        confirmButtonText: 'OK'
    });
});
</script>
<?php endif; ?>

<?php echo $__env->make('layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH C:\xampp\htdocs\machine_health\resources\views/komatsu/sn-ref.blade.php ENDPATH**/ ?>